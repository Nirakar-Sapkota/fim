﻿
$userDefinedPath = Read-Host -Prompt "Enter Path of the File you would like to monitor"

Write-Host ""
Write-Host "What would you Like to do?"
Write-Host ""
Write-Host "A). Collect new BaseLine"
Write-Host "B). Begin Monitoring files with existing Baseline"
Write-Host ""

Function Calculate-File-Hash($userDefinedPath){
    $fileHash = Get-ChildItem $userDefinedPath -Recurse -File | Get-FileHash -Algorithm SHA256
    return $fileHash
}

$response = Read-Host -Prompt "Please Enter Option A or B"

Function Erase-Baseline-If-Already-Exists(){
    $baselineExists = Test-Path -Path $userDefinedPath\baseline.txt
    
    if($baselineExists){
        #Delete file baseline.txt
        Remove-Item -Path $userDefinedPath\baseline.txt
    }
}


if($response -eq "A".ToUpper()){
    #Delete baseline.txt if it already exists
    Erase-Baseline-If-Already-Exists

    #Calculate Hash From the target files and store in baseline.txt
    Write-Host 'Calculate Hashes, make new baseline.txt?'

    #Collect all files in the target folder
    $files = Get-ChildItem -Path $userDefinedPath 
    

    #for each file , calculate the hash, and write to baseline.txt
    foreach($f in $files){
       $hash = Calculate-File-Hash $f.FullName
       "$($hash.Path)|$($hash.Hash)" | Out-File -FilePath $userDefinedPath\baseline.txt -Append
    }
}

elseif($response -eq "B".ToUpper()){
    #Empty Dictionary 
    $fileHashDictionary =@{}
    #Load File | hash from baseline.txt and store them in a dictionary
    $filePathsAndHashes = Get-Content -Path $userDefinedPath\baseline.txt
    foreach($f in $filePathsAndHashes){
        $fileHashDictionary.add($f.Split("|")[0],$f.Split("|")[1]) 
    }
    
    #Begin Constantly keep checking
  while($true){
    Start-Sleep -Seconds 2
     #Collect all files in the target folder
     $files = Get-ChildItem -Path $userDefinedPath 
    

     #for each file , calculate the hash, and write to baseline.txt
     foreach($f in $files){
        $hash = Calculate-File-Hash $f.FullName
        #"$($hash.Path)|$($hash.Hash)" | Out-File -FilePath $userDefinedPath\baseline.txt -Append
            if($null -eq $fileHashDictionary[$hash.Path]){
                #A new file has been Created
                Write-Host "$($hash.Path) has been Created" -ForegroundColor Green
            }

            #Notify if new file has been changed
            if($fileHashDictionary[$hash.Path] -eq $hash.Hash){
                #The file has not changed
            }else{
                #File Has been compromised!, notify ADMIN!!║¼┌"
                Write-Host "$($hash.Path) has been Modified!!" -ForegroundColor Red
            }
     }

     foreach($key in $fileHashDictionary.Keys){
        $baselineFileStillExists = Test-Path -Path $key

        if(-Not $baselineFileStillExists){
            #One of the file/s has been deleted, notify Admin"
            Write-Host "$($key) has been Deleted!! Alert!! ADMIN" -ForegroundColor DarkRed -BackgroundColor Gray
        }
     }
  }

    #Begin monitoring files with saved baseline file
    Write-Host "Read existing baseline.txt, start monitoring files" -ForegroundColor Yellow

}
